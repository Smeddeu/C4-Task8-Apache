 <?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html>
<body>

<?php
// Set session variables
$_SESSION["item1"] = "Peanuts";
$_SESSION["item2"] = "Toiletpaper";
echo "Session variables are set.";
?>

</body>
</html>
