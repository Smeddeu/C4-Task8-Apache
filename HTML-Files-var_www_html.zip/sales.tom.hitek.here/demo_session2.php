 <?php
session_start();
?>
<!DOCTYPE html>
<html>
<body>

<?php
// Echo session variables that were set on previous page
echo "Item in basket " . $_SESSION["item1"] . ".<br>";
echo "Item Nr.2 in basket " . $_SESSION["item2"] . ".";
?>

</body>
</html> 
